#!/bin/bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 THREAD_ID" >&2
  exit 2
fi

THREAD_ID="$1"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-$(command -v python3 || true)}"
CODEX_BIN="${CODEX_BIN:-$(command -v codex || true)}"

if [[ -z "$PYTHON_BIN" ]]; then
  echo "python3 not found; set PYTHON_BIN=/absolute/path/to/python3" >&2
  exit 3
fi
if [[ -z "$CODEX_BIN" ]]; then
  echo "codex not found; set CODEX_BIN=/absolute/path/to/codex" >&2
  exit 4
fi

read -r -p "Confirm this thread will be dedicated to the watchdog and Codex Desktop is not running it [y/N]: " ANSWER
case "$ANSWER" in
  y|Y|yes|YES) ;;
  *) echo "Cancelled."; exit 1 ;;
esac

SAFE_ID="${THREAD_ID//-/}"
LABEL="local.codex.goal-watchdog.${SAFE_ID}"
PLIST="$HOME/Library/LaunchAgents/${LABEL}.plist"
LOG_DIR="$HOME/.codex/watchdogs"
mkdir -p "$HOME/Library/LaunchAgents" "$LOG_DIR"

xml_escape() {
  printf '%s' "$1" | sed -e 's/&/\&amp;/g' -e 's/</\&lt;/g' -e 's/>/\&gt;/g' -e 's/"/\&quot;/g' -e "s/'/\&apos;/g"
}

PYTHON_XML="$(xml_escape "$PYTHON_BIN")"
CODEX_XML="$(xml_escape "$CODEX_BIN")"
SCRIPT_XML="$(xml_escape "$SCRIPT_DIR/codex_goal_watchdog.py")"
PATH_XML="$(xml_escape "$PATH")"
HOME_XML="$(xml_escape "$HOME")"
OUT_XML="$(xml_escape "$LOG_DIR/${THREAD_ID}.launchd.out.log")"
ERR_XML="$(xml_escape "$LOG_DIR/${THREAD_ID}.launchd.err.log")"

cat > "$PLIST" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/usr/bin/caffeinate</string>
    <string>-i</string>
    <string>${PYTHON_XML}</string>
    <string>${SCRIPT_XML}</string>
    <string>--thread</string>
    <string>${THREAD_ID}</string>
    <string>--codex-bin</string>
    <string>${CODEX_XML}</string>
    <string>--approval-policy</string>
    <string>preserve</string>
    <string>--sandbox</string>
    <string>preserve</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>HOME</key>
    <string>${HOME_XML}</string>
    <key>PATH</key>
    <string>${PATH_XML}</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>ThrottleInterval</key>
  <integer>30</integer>
  <key>ProcessType</key>
  <string>Background</string>
  <key>StandardOutPath</key>
  <string>${OUT_XML}</string>
  <key>StandardErrorPath</key>
  <string>${ERR_XML}</string>
</dict>
</plist>
PLIST

plutil -lint "$PLIST"
DOMAIN="gui/$(id -u)"
launchctl bootout "$DOMAIN" "$PLIST" 2>/dev/null || true
launchctl bootstrap "$DOMAIN" "$PLIST"
launchctl kickstart -k "$DOMAIN/$LABEL"

echo "Installed and started: $LABEL"
echo "Plist: $PLIST"
echo "Logs: $LOG_DIR/${THREAD_ID}.launchd.{out,err}.log"
echo "Stop with: $SCRIPT_DIR/uninstall_launchd.sh $THREAD_ID"
