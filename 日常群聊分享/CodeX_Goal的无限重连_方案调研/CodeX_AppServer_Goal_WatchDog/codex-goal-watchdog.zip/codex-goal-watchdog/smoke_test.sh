#!/bin/bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
TMP="$(mktemp -d)"
PORT="18997"
cleanup() {
  kill "${HTTP_PID:-}" 2>/dev/null || true
  rm -rf "$TMP"
}
trap cleanup EXIT

cat > "$TMP/mock_codex.py" <<'PY'
#!/usr/bin/env python3
import json
import sys
import time

status = "blocked"
thread_id = "test-thread"
failed_turn = {
    "id": "turn-1",
    "items": [],
    "itemsView": "summary",
    "status": "failed",
    "error": {
        "message": "exceeded retry limit, last status: 429 Too Many Requests",
        "codexErrorInfo": {
            "responseTooManyFailedAttempts": {"httpStatusCode": 429}
        },
        "additionalDetails": None,
    },
    "startedAt": int(time.time()) - 5,
    "completedAt": int(time.time()),
    "durationMs": 5000,
}

for raw in sys.stdin:
    message = json.loads(raw)
    request_id = message.get("id")
    method = message.get("method")
    params = message.get("params") or {}
    if request_id is None:
        continue
    if method == "initialize":
        result = {
            "userAgent": "mock",
            "codexHome": "/tmp/mock",
            "platformFamily": "unix",
            "platformOs": "macos",
        }
    elif method == "thread/resume":
        result = {
            "thread": {"id": thread_id, "status": {"type": "idle"}, "turns": []},
            "initialTurnsPage": {
                "data": [failed_turn],
                "nextCursor": None,
                "backwardsCursor": None,
            },
        }
    elif method == "thread/goal/get":
        result = {
            "goal": {
                "threadId": thread_id,
                "objective": "test",
                "status": status,
                "tokenBudget": None,
                "tokensUsed": 1,
                "timeUsedSeconds": 1,
                "createdAt": 1,
                "updatedAt": 2,
            }
        }
    elif method == "thread/goal/set":
        status = params.get("status", status)
        result = {
            "goal": {
                "threadId": thread_id,
                "objective": "test",
                "status": status,
                "tokenBudget": None,
                "tokensUsed": 1,
                "timeUsedSeconds": 1,
                "createdAt": 1,
                "updatedAt": 3,
            }
        }
    elif method == "thread/read":
        result = {
            "thread": {
                "id": thread_id,
                "status": {"type": "idle"},
                "turns": [failed_turn] if params.get("includeTurns") else [],
            }
        }
    elif method == "thread/list":
        result = {
            "data": [
                {
                    "id": thread_id,
                    "updatedAt": int(time.time()),
                    "createdAt": int(time.time()),
                    "preview": "Mock thread",
                    "cwd": "/tmp/mock",
                    "status": {"type": "notLoaded"},
                }
            ],
            "nextCursor": None,
            "backwardsCursor": None,
        }
    else:
        print(
            json.dumps(
                {"id": request_id, "error": {"code": -32601, "message": "unknown"}}
            ),
            flush=True,
        )
        continue
    print(json.dumps({"id": request_id, "result": result}), flush=True)
PY
chmod +x "$TMP/mock_codex.py"

python3 -m http.server "$PORT" --bind 127.0.0.1 --directory "$TMP" >/dev/null 2>&1 &
HTTP_PID=$!
sleep 0.2

python3 -m py_compile "$ROOT/codex_goal_watchdog.py"
python3 "$ROOT/codex_goal_watchdog.py" \
  --thread test-thread \
  --codex-bin "$TMP/mock_codex.py" \
  --once \
  --poll-seconds 0 \
  --base-delay-seconds 0 \
  --rate-limit-base-seconds 0 \
  --max-delay-seconds 0 \
  --probe-url "http://127.0.0.1:${PORT}/" \
  --state-file "$TMP/state.json" | tee "$TMP/watch.log"

grep -q "goal reactivation requested" "$TMP/watch.log"
python3 "$ROOT/codex_goal_watchdog.py" --list --codex-bin "$TMP/mock_codex.py" | grep -q test-thread

echo "Smoke test passed."
