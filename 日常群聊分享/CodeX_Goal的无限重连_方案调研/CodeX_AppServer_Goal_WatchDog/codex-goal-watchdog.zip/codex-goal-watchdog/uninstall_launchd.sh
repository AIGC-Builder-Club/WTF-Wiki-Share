#!/bin/bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 THREAD_ID" >&2
  exit 2
fi

THREAD_ID="$1"
SAFE_ID="${THREAD_ID//-/}"
LABEL="local.codex.goal-watchdog.${SAFE_ID}"
PLIST="$HOME/Library/LaunchAgents/${LABEL}.plist"
DOMAIN="gui/$(id -u)"

launchctl bootout "$DOMAIN" "$PLIST" 2>/dev/null || true
rm -f "$PLIST"
echo "Stopped and removed: $LABEL"
